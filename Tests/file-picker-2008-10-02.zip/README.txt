
Program Name: File Picker
Program URI: http://code.google.com/p/file-picker/
Description: Display and choose files from your website.

Author: Hpyer
Author URI: http://www.hpyer.cn
E-mail: hpyer[at]yahoo.cn

Document & Demo: index.php
History: HISTORY.txt
License: GPL (GPL-LICENSE.txt) & MIT (MIT-LICENSE.txt)
