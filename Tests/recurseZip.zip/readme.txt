=======PHP Zip files and directory class========

Author: Archan Ghosal.

Author Link: http://ramui.com/

Date of Release: 5th July 2011.

Product Version: 1.0

Description: This PHP class is capable of Zipping a single file or even an entire directory. To use this Zip class file,
	-You have to include this file in your project.
	-Create class object.
	-Call the public function compress(); this function takes two arguments, source and destination. You can omit the second argument, and then working folder will be the destination. On success this function will return the Zip file name.
	-An example file is given to understand the mater.

System Requirements:
The system required to install or run this script is: -
	-PHP version 5.2.1 or higher;
	-PHP extension Zlib (http://www.zlib.net/) written by Jean-loup Gailly;

Price: Free.

Online Documentation Link: http://ramui.com/articles/php-zip-files-and-directory.html

Online Support Link: http://ramui.com/articles/php-zip-files-and-directory.html

Report bug: http://ramui.com/articles/php-zip-files-and-directory.html

Copyright: Copyright (c) 2011 http://ramui.com. All rights reserved.
This product is protected by copyright and distributed under licenses restricting copying, distribution. Permission is granted to the public to download and use this script provided that this Notice and any statement of authorship are reproduced in every page on all copies of the script.

DISCLAIMER OF WARRANTIES: THIS SCRIPT PRODUCT IS PROVIDED "AS-IS". NO WARRANTY OF ANY KIND IS EXPRESSED OR IMPLIED. YOU (RECEPIENT) USE THIS SCRIPT AT YOUR (RECEPIENTS) OWN RISK. TO THE MAXIMUM EXTENT PERMITTED UNDER APPLICABLE LAWS, AUTHOR EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. AUTHOR DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED IN THE SCRIPT WILL MEET YOUR REQUIREMENTS, OR THAT THE OPERATION OF THE SCRIPT WILL BE UNINTERRUPTED OR ERROR-FREE, OR THAT DEFECTS IN THE SCRIPT WILL BE CORRECTED. FURTHERMORE, AUTHOR DOES NOT WARRANT OR MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE RESULTS OF THE USE OF THE SCRIPT IN TERMS OF ITS CORRECTNESS, ACCURACY, RELIABILITY, OR OTHERWISE. NO ORAL OR WRITTEN INFORMATION OR ADVICE GIVEN BY AUTHOR OR RAMUI.COM SHALL CREATE A WARRANTY OR IN ANY WAY INCREASE THE SCOPE OF ANY WARRANTY.
