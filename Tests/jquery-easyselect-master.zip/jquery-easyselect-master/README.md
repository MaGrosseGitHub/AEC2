jQuery easySelect [![Build Status](http://img.shields.io/travis/tameraydin/jquery-easyselect/master.svg?style=flat-square)](https://travis-ci.org/tameraydin/jquery-easyselect)
=================

```console
bower install easyselect
```
or manually [download](https://github.com/tameraydin/jquery-easyselect/archive/master.zip).

Please check the GitHub Page for more information - http://tameraydin.github.io/jquery-easyselect/.

## License

MIT [http://tameraydin.mit-license.org/](http://tameraydin.mit-license.org/)
